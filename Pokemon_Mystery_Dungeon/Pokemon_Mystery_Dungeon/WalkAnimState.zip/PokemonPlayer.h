#pragma once
#include "PokemonBase.h"

class PokemonPlayer : public PokemonBase
{
private:

protected:

public:

};

