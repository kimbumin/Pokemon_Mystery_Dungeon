#include "StartScene.h"

HRESULT StartScene::Init()
{

	return S_OK;
}

void StartScene::Release()
{
}

void StartScene::Update()
{
}

void StartScene::Render(HDC hdc)
{
}
