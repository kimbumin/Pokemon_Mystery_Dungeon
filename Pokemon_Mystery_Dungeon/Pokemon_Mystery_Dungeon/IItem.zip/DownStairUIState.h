#pragma once
#include "UIState.h"
#include "UIElement.h"

class UIElementImage;
class UIElementText;
class DownStairUIState : public UIState, public UIElement
{
private:
    UIElementImage* DownStairBox = nullptr;
    UIElementImage* YesOrNoBox = nullptr;

    UIElementImage* Cursor = nullptr;

    UIElementText* IsDownText = nullptr;
    UIElementText* YesText = nullptr;
    UIElementText* NoText = nullptr;


    const int OffsetY[2] = {30, 60};

    int YIndex = 0;

    static bool s_isCooldown;
    static float s_cooldownTimer;

public:
    HRESULT Init() override;
    void Release() override;
    void Update() override;
    void Update(float dt) override;
    void Render(HDC hdc) override;
    ~DownStairUIState() override;
    static bool IsCooldown()
    {
        return s_isCooldown;
    }
    static void SetCooldown(bool value, float duration = 3.0f)
    {
        s_isCooldown = value;
        s_cooldownTimer = value ? duration : 0.0f;
    }

};
