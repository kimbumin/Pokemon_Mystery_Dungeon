#include "TitleUIState.h"

#include "Image.h"

HRESULT TitleUIState::Init()
{
    return S_OK;
}

void TitleUIState::Release()
{
}

void TitleUIState::Update()
{
}

void TitleUIState::Render(HDC hdc)
{
}

TitleUIState::~TitleUIState()
{
}
