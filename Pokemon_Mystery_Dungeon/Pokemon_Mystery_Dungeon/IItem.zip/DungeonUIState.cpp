#include "DungeonUIState.h"

#include "ImageGDIPlusManager.h"
#include "UIManager.h"
#include "DungeonScene.h"

HRESULT DungeonUIState::Init()
{
    // �̹���
    auto& manager = *ImageGDIPlusManager::GetInstance();
    auto DungeonInfoBoxImage = manager.AddImage(
        "DungeonInfoBox", L"Image/UIImage/DungeonUIState/DungeonInfoBox.png");
    auto CursorImage =
        manager.AddImage("Cursor", L"Image/UIImage/DungeonUIState/Cursor.png");
    //auto WaterTypeGifImage = manager.AddImage(
    //    "WaterType", L"Image/UIImage/DungeonUIState/waterType.gif", 1, 1, true);
    //auto FireTypeGifImage = manager.AddImage(
    //    "FireType", L"Image/UIImage/DungeonUIState/fireType.gif", 1, 1, true);

    // UI ������Ʈ ����
    DungeonInfoBox = new UIElementImage();
    DungeonInfoBox->SetImage(DungeonInfoBoxImage);
    DungeonInfoBox->SetLocalPos(25, 100);
    DungeonInfoBox->setAlpha(0.95f);
    DungeonInfoBox->SetParent(this);

    Cursor = new UIElementImage();
    Cursor->SetImage(CursorImage);
    Cursor->SetLocalPos(30, OffsetY[0]);
    Cursor->SetParent(DungeonInfoBox);

    int parentWidth = DungeonInfoBox->GetImageWidth();

    // �ڽ� ��ü ���� waterType
    //WaterType = new UIElementImage();
    //WaterType->SetImage(WaterTypeGifImage);
    //WaterType->SetLocalPos(parentWidth - 120, OffsetY[0]);
    //WaterType->setAlpha(0.5f);
    //WaterType->SetSpeed(0.5f);
    //WaterType->setScale(0.17f, 0.17f);
    //WaterType->SetParent(DungeonInfoBox);

    // �ڽ� ��ü ���� waterTypeText
    IceTypeText = new UIElementText();
    IceTypeText->SetText(L"Ice Dungeon");
    IceTypeText->SetLocalPos(50, OffsetY[0]);
    IceTypeText->SetParent(DungeonInfoBox);

    // �ڽ� ��ü ���� fireType
    //FireType = new UIElementImage();
    //FireType->SetImage(FireTypeGifImage);
    //FireType->SetLocalPos(parentWidth - 120, OffsetY[1]);
    //FireType->setAlpha(0.5f);
    //FireType->SetSpeed(0.5f);
    //FireType->setScale(0.17f, 0.17f);
    //FireType->SetParent(DungeonInfoBox);

    // �ڽ� ��ü ���� fireTypeText
    MagmaTypeText = new UIElementText();
    MagmaTypeText->SetText(L"Magma Dungeon");
    MagmaTypeText->SetLocalPos(50, OffsetY[1]);
    MagmaTypeText->SetParent(DungeonInfoBox);

    // �ڽ� ��ü ���� forestTypeText
    ForestTypeText = new UIElementText();
    ForestTypeText->SetText(L"Forest Dungeon");
    ForestTypeText->SetLocalPos(50, OffsetY[2]);
    ForestTypeText->SetParent(DungeonInfoBox);


    UpdateRealPos();
    return S_OK;
}

void DungeonUIState::Release()
{
}

void DungeonUIState::Update()
{
    if(KeyManager::GetInstance()->IsOnceKeyDown(VK_DOWN))
    {
        YIndex = (YIndex + 1) % 3;
        Cursor->SetLocalPos(25, OffsetY[YIndex]);
        Cursor->UpdateRealPos();
    }
    else if (KeyManager::GetInstance()->IsOnceKeyDown(VK_UP))
    {
        YIndex = (YIndex - 1 + 3) % 3;
        Cursor->SetLocalPos(25, OffsetY[YIndex]);
        Cursor->UpdateRealPos();
    }

    if (KeyManager::GetInstance()->IsOnceKeyDown(0x5A)) // zŰ
    {
        if (YIndex == 0)
        {
            UIManager::GetInstance()->SetDungeonType(DUNGEON_TYPE_ICE);
            UIManager::GetInstance()->ChangeState("IdleUI");
            SceneManager::GetInstance()->AddScene("DungeonScene", new DungeonScene);
            SceneManager::GetInstance()->ChangeScene("DungeonScene");

        }
        else if (YIndex == 1)
        {
            UIManager::GetInstance()->SetDungeonType(DUNGEON_TYPE_MAGMA);
            UIManager::GetInstance()->ChangeState("IdleUI");
            SceneManager::GetInstance()->AddScene("DungeonScene",
                                                  new DungeonScene);
            SceneManager::GetInstance()->ChangeScene("DungeonScene");

        }
        else if (YIndex == 2)
        {
            UIManager::GetInstance()->SetDungeonType(DUNGEON_TYPE_FOREST);
            UIManager::GetInstance()->ChangeState("IdleUI");
            SceneManager::GetInstance()->AddScene("DungeonScene",
                                                  new DungeonScene);
            SceneManager::GetInstance()->ChangeScene("DungeonScene");
        }
    }

    if (KeyManager::GetInstance()->IsOnceKeyDown(0x58))  // 'X' Ű
    {
        UIManager::GetInstance()->ChangeState("IdleUI");
    }

}

void DungeonUIState::Render(HDC hdc)
{
    if (DungeonInfoBox)
    {
        DungeonInfoBox->Render(hdc);
    }

    if (WaterType)
    {
        WaterType->Render(hdc);
    }
    if (FireType)
    {
        FireType->Render(hdc);
    }
}

DungeonUIState::~DungeonUIState()
{
}
